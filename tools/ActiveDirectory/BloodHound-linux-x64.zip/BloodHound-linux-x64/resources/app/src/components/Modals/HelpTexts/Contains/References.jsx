const References = () => {
    let text = `<a href="https://wald0.com/?p=179">https://wald0.com/?p=179</a>
    <a href="https://blog.cptjesus.com/posts/bloodhound15">https://blog.cptjesus.com/posts/bloodhound15</a>`;
    return { __html: text };
};

export default References;
