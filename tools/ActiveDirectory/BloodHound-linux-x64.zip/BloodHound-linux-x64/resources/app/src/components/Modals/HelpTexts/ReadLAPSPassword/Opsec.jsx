const Opsec = () => {
    let text = `Reading properties from LDAP is an extremely low risk operation.`;
    return { __html: text };
};

export default Opsec;
