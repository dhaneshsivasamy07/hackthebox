const References = () => {
    //TODO: DO this
    let text = `<a href="https://www.dsinternals.com/en/retrieving-cleartext-gmsa-passwords-from-active-directory/">https://www.dsinternals.com/en/retrieving-cleartext-gmsa-passwords-from-active-directory/</a>
    <a href="https://www.powershellgallery.com/packages/DSInternals/">https://www.powershellgallery.com/packages/DSInternals/</a>
    <a href="https://github.com/markgamache/gMSA/tree/master/PSgMSAPwd">https://github.com/markgamache/gMSA/tree/master/PSgMSAPwd</a>
    <a href="https://adsecurity.org/?p=36">https://adsecurity.org/?p=36</a>
    <a href="https://adsecurity.org/?p=2535">https://adsecurity.org/?p=2535</a>
    <a href="https://www.ultimatewindowssecurity.com/securitylog/encyclopedia/event.aspx?eventID=4662">https://www.ultimatewindowssecurity.com/securitylog/encyclopedia/event.aspx?eventID=4662</a>`;
    return { __html: text };
};

export default References;
